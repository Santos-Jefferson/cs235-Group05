#ifndef HANDLETRANS_H
#define HANDLETRANS_H

#include "dollars.h"
struct HandleTrans
{
   Dollars price;
   int     volume;
   Dollars profit;
};

#endif
